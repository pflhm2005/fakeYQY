<template>
    <!--底部-->
    <div class="footer clearfix">
        <div class="f-content box">
            
        </div>
    </div>
</template>
<script>
    export default {

    }
</script>
<style lang='less'>
    .footer {
        clear: both;
        background-color: #202020;
        height: 200px;
        width: 100%;
    }
</style>